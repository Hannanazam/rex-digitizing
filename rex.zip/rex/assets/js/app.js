$(".password_field .icon").click(function(){
    $(this).find(".fa-eye").toggleClass("fa-eye-slash");
    console.log("running")
    // $(this).find("i.fas.fa-eye-splash").toggleClass("i.fas.fa-eye");
});